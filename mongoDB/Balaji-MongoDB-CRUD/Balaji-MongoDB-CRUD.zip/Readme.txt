Folder Name: BALAJI-MONGODB-CRUD
Database : mongoDB 

step 1 : Extract the zip folder

step 2 : Go to the BALAJI-MONGODB-CRUD path directory and open COMMAND PROMPT

step 3 : Run npm i 

step 4 : Run npm start

step 5 : The server is running on 5000. URL : http://localhost:5000/

step 6 : Go to postman. Switch GET method , use the endpoint /getAllTransactions to get all Transactions.

step 7 : Switch POST method , use the endpoint /createTransactions to get create Transactions.

step 8 : Switch PUT method , use the endpoint /updateTransactions/id to update existed Transactions.

step 9 : Switch DELETE method , use the endpoint /deleteTransactions/id to delete Transactions in DB.

step 10 : To get a specfic Transactions details , use the endpoint /getTransaction/id to get specific Transaction details.
